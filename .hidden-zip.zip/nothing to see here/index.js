const chalk = require("chalk")
const fs = require("fs")
const congratulations = require(`${__dirname}/congratulations`)

const helpFlag = process.argv.find(e => e === "--help")
const stepFlag = process.argv.find(e => (new RegExp(/^\-\-step\-[0-9]$/)).test(e))
const hintFlag = process.argv.find(e => e === "--hint")

if (!helpFlag && !stepFlag) {
  console.log("Try asking me for --help")
  process.exit(0)
} else if (helpFlag && !stepFlag) {
  console.log("You must be $AUTHORIZED to continue.")
  if (hintFlag) {
    console.log("Try to source env.sh.")
  }
  process.exit(0)
}

switch (stepFlag) {
  case "--step-1":
    runStep(runStep1)
    break
  case "--step-2":
    runStep(runStep2)
    break
  case "--step-3":
    runStep(runStep3)
    break
  case "--step-4":
    runStep(runStep4)
    break
  default:
    console.error(`Invalid flag ${stepFlag}`)
}

function runStep(stepFunc) {
  try {
    if (process.env.AUTHORIZED) {
      stepFunc()
      process.exit(0)
    } else {
      console.error("You are not $AUTHORIZED to run this command.")
      process.exit(1)
    }
  }
  catch (e) {
    process.exit(1)
  }
}

function runStep1() {
  if (hintFlag) {
    console.log("Can you reach out and " + chalk.red("touch") + " a file?")
  }

  if (fs.existsSync(`${__dirname}/exercise/start`)) {
    console.log("Step 1 passed!")
  } else {
    console.error("File 'exercise/start' not found")
    throw new Error()
  }
}

function runStep2() {
  if (hintFlag) {
    console.log(chalk.blue(chalk.bold("M")) + "a" + chalk.blue(chalk.bold("k")) + "e like a "
      + chalk.blue(chalk.bold("dir")) + "ectory and " + chalk.blue(chalk.bold("m")) + "o" + chalk.blue(chalk.bold("v")) + "e.")
  }

  if (fs.existsSync(`${__dirname}/exercise/step2/success`)) {
    console.log("Step 2 passed!")
  } else {
    console.error("File step2/start not found")
    throw new Error()
  }
}

function runStep3() {
  if (hintFlag) {
    console.log("Cmd+c, recursive, don't forget the new name")
  }

  if (fs.existsSync(`${__dirname}/exercise/step3/success`)) {
    console.log("Step 3 passed!")
  } else {
    console.error("File step3/start not found")
    throw new Error()
  }
}

function runStep4() {
  if (hintFlag) {
    console.log(chalk.magenta(chalk.bold("R")) + "e" + chalk.magenta(chalk.bold("m")) + "ove " + chalk.magenta(chalk.bold("r")) + "ecursively")
  }

  if (!fs.readdirSync(`${__dirname}/exercise`).length) {
    console.log("Step 4 passed!")
    try {
      fs.writeFileSync(`${__dirname}/exercise/success.txt`, congratulations)
    } catch (e) {
      console.error("error writing file", e)
    }
    console.log("File 'success.txt' created in exercise directory.")
    console.log("Now 😺📄 to finish.")
  } else {
    console.error("exercise directory must be empty")
    throw new Error()
  }
}