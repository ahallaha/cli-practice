Don't forget to install dependencies.

Then try running index.js and asking for --help.

You can use the `--hint` flag for a hint. If using an npm run script the `--hint` flag can be used as follows:
`npm run scriptName:hint`